package com.nexus.ffmod

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView

class FloatingMenuService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var bubble: View
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        criarNotificacaoForeground()
        criarBotaoFlutuante()
    }

    private fun criarNotificacaoForeground() {
        val canal = "ffmod"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(canal, "FF Mod", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notif = Notification.Builder(this, canal)
            .setContentTitle("FF Mod Nexus ativo")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        startForeground(1, notif)
    }

    private fun criarBotaoFlutuante() {
        val hoje = LayoutInflater.from(this)
        bubble = hoje.inflate(R.layout.menu_flutuante, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 200

        windowManager.addView(bubble, params)

        // botão "AI" flutuante que expande o painel
        bubble.findViewById<View>(R.id.fab).setOnClickListener {
            expanded = !expanded
            bubble.findViewById<View>(R.id.panel).visibility =
                if (expanded) View.VISIBLE else View.GONE
        }

        // opções do mod
        bubble.findViewById<RadioButton>(R.id.rbCapa).setOnClickListener {
            NativeBridge.applyMode(MODE_CAPA_PESCOCO)
        }
        bubble.findViewById<RadioButton>(R.id.rbFull).setOnClickListener {
            NativeBridge.applyMode(MODE_FULL_CAPA)
        }

        // arrastar
        bubble.findViewById<View>(R.id.fab).setOnTouchListener(object : View.OnTouchListener {
            var lastX = 0
            var lastY = 0
            var startX = 0
            var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lastX = params.x; lastY = params.y
                        startX = e.rawX.toInt(); startY = e.rawY.toInt()
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = lastX + (e.rawX.toInt() - startX)
                        params.y = lastY + (e.rawY.toInt() - startY)
                        windowManager.updateViewLayout(bubble, params)
                    }
                }
                return false
            }
        })
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val MODE_CAPA_PESCOCO = 0
        const val MODE_FULL_CAPA = 1
    }
}
