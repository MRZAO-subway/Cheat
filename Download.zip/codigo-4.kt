package com.nexus.ffmod

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val REQ_OVERLAY = 1001
    private val FF_PACKAGE = "com.dts.freefireth"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnInject).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, REQ_OVERLAY)
            } else {
                injetar()
            }
        }
    }

    private fun injetar() {
        Toast.makeText(this, "Injetando cheat...", Toast.LENGTH_SHORT).show()

        // 1) inicia o menu flutuante
        val svc = Intent(this, FloatingMenuService::class.java)
        ContextCompat.startForegroundService(this, svc)

        // 2) abre o Free Fire
        val launchFF = packageManager.getLaunchIntentForPackage(FF_PACKAGE)
        if (launchFF != null) {
            launchFF.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchFF)
        } else {
            Toast.makeText(this, "Free Fire não instalado", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) injetar()
    }
}
